"""Project: Color Sorting Robotic Arm with Camera
Raspberry Pi Zero 2 W + JT-ZERO-V2.0 camera (OV5647, mini CSI) + PCA9685 + 4x MG90S arm.
The camera looks down at a fixed pick-up spot. When a cube stays there, its color is read
(red / green / blue) and the arm moves it to the bin of that color.
Install:  sudo apt install python3-opencv python3-picamera2
          python3 -m venv --system-site-packages ~/arm && ~/arm/bin/pip install adafruit-circuitpython-servokit
Run:      ~/arm/bin/python ch14_color_sort_arm.py      (add --test to only print colors)
"""
import sys, time
import cv2
import numpy as np

# ---------- color detection (works on any BGR image) ----------
RANGES = {                       # OpenCV hue 0..179; red wraps around 0
    "red":   [((0, 110, 70), (8, 255, 255)), ((170, 110, 70), (179, 255, 255))],
    "green": [((40, 80, 60), (85, 255, 255))],
    "blue":  [((95, 110, 60), (130, 255, 255))],
}
MIN_PIXELS = 0.25                # at least 25% of the ROI must have the color

def detect_color(frame, roi=(0.35, 0.65, 0.35, 0.65)):
    h, w = frame.shape[:2]
    y0, y1, x0, x1 = int(roi[0]*h), int(roi[1]*h), int(roi[2]*w), int(roi[3]*w)
    hsv = cv2.cvtColor(cv2.GaussianBlur(frame[y0:y1, x0:x1], (5, 5), 0), cv2.COLOR_BGR2HSV)
    best, best_frac = None, 0.0
    for name, ranges in RANGES.items():
        mask = sum(cv2.inRange(hsv, lo, hi) for lo, hi in ranges)
        frac = cv2.countNonZero(mask) / mask.size
        if frac > best_frac:
            best, best_frac = name, frac
    return (best if best_frac >= MIN_PIXELS else None), round(best_frac, 2)

# ---------- arm poses: base, shoulder, elbow, gripper (degrees) — calibrate on your arm ----------
OPEN, CLOSE = 60, 20
HOME  = (90, 90, 90, OPEN)
ABOVE = (90, 110, 70, OPEN)      # above the pick-up spot
PICK  = (90, 135, 55, OPEN)      # down at the pick-up spot
BINS  = {"red": 30, "green": 150, "blue": 175}   # base angle of each bin
DROP_SHOULDER, DROP_ELBOW = 110, 80

def make_arm():
    from adafruit_servokit import ServoKit
    kit = ServoKit(channels=16)                  # PCA9685 at 0x40, channels 0..3
    for ch in range(4):
        kit.servo[ch].set_pulse_width_range(500, 2400)
    cur = list(HOME)
    for ch in range(4):
        kit.servo[ch].angle = cur[ch]

    def move(pose, step=2, delay=0.015):         # smooth: a few degrees at a time
        while True:
            done = True
            for ch in range(4):
                d = pose[ch] - cur[ch]
                if d:
                    cur[ch] += max(-step, min(step, d)); kit.servo[ch].angle = cur[ch]; done = False
            if done:
                return
            time.sleep(delay)
    return move

def sort_once(move, color):
    move(ABOVE); move(PICK)
    move(PICK[:3] + (CLOSE,)); time.sleep(0.3)    # grip
    move(ABOVE[:3] + (CLOSE,))
    base = BINS[color]
    move((base, DROP_SHOULDER, DROP_ELBOW, CLOSE))
    move((base, DROP_SHOULDER, DROP_ELBOW, OPEN)); time.sleep(0.3)   # release
    move(HOME)

def main():
    test = "--test" in sys.argv
    from picamera2 import Picamera2
    cam = Picamera2()
    cam.configure(cam.create_preview_configuration(main={"size": (320, 240), "format": "RGB888"}))
    cam.start(); time.sleep(1)
    cam.set_controls({"AeEnable": False, "AwbEnable": False})   # fixed exposure: stable colors
    move = None if test else make_arm()
    last, same = None, 0
    while True:
        frame = cam.capture_array()              # with RGB888 the array is in BGR order for OpenCV
        color, frac = detect_color(frame)
        same = same + 1 if color == last else 0
        last = color
        print(color, frac)
        if color and same >= 5 and move:         # cube stayed for 5 frames: sort it
            sort_once(move, color); last, same = None, 0
        time.sleep(0.05)

if __name__ == "__main__":
    main()
