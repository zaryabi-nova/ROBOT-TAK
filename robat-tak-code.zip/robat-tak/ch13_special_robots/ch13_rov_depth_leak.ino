// ROV bench test: depth from MS5837 (I2C) + simple leak probe
// Library: "BlueRobotics MS5837 Library" (Arduino Library Manager)
// Leak probe: two bare wires inside the hull -> pin 2 (INPUT_PULLUP) and GND; water closes the gap.
#include <Wire.h>
#include "MS5837.h"

MS5837 sensor;
const int LEAK_PIN = 2;
float zeroDepth = 0;                       // depth reading at the water surface

void setup() {
  Serial.begin(115200);
  pinMode(LEAK_PIN, INPUT_PULLUP);
  Wire.begin();
  while (!sensor.init()) {                 // sensor not found: check wiring and 3.3V
    Serial.println("MS5837 not found");
    delay(2000);
  }
  sensor.setModel(MS5837::MS5837_30BA);    // use MS5837_02BA for the 2-bar model
  sensor.setFluidDensity(997);             // fresh water; sea water: 1029
  sensor.read();
  zeroDepth = sensor.depth();              // start the test at the surface
}

void loop() {
  sensor.read();
  Serial.print("P(mbar)="); Serial.print(sensor.pressure());
  Serial.print("  T(C)=");  Serial.print(sensor.temperature());
  Serial.print("  depth(m)="); Serial.println(sensor.depth() - zeroDepth);
  if (digitalRead(LEAK_PIN) == LOW) Serial.println("!!! LEAK - surface now !!!");
  delay(500);
}
