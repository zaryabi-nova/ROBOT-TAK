// Robot (receiver): ESP32 car + nRF24L01, driven by the Joystick Shield remote
// nRF24 on ESP32 VSPI: SCK=18, MISO=19, MOSI=23, CSN=5, CE=4; 10..100 uF capacitor on the module power
// Motors: TB6612/L298N  left ENA=25 IN1=26 IN2=27, right ENB=14 IN3=32 IN4=33; LED=2, buzzer=12
#include <SPI.h>
#include <RF24.h>

RF24 radio(4, 5);                          // CE, CSN
const byte ADDR[6] = "RTAK1";
struct Packet { int16_t x, y; uint8_t buttons, counter; uint16_t check; } pkt;

const int ENA = 25, IN1 = 26, IN2 = 27, ENB = 14, IN3 = 32, IN4 = 33;
const int LED = 2, BUZZER = 12, DEAD = 40;
unsigned long lastPacket = 0;
bool lights = false; uint8_t lastButtons = 0;

void motor(int en, int a, int b, float s) {
  s = constrain(s, -1.0f, 1.0f);
  digitalWrite(a, s > 0); digitalWrite(b, s < 0);
  analogWrite(en, (int)(fabs(s) * 255));
}
void drive(float l, float r) { motor(ENA, IN1, IN2, l); motor(ENB, IN3, IN4, r); }
float axis(int v) { return abs(v) < DEAD ? 0 : constrain(v / 512.0f, -1.0f, 1.0f); }

void setup() {
  Serial.begin(115200);
  int outs[] = {ENA, IN1, IN2, ENB, IN3, IN4, LED, BUZZER};
  for (int p : outs) pinMode(p, OUTPUT);
  if (!radio.begin()) Serial.println("nRF24 not found");
  radio.setPALevel(RF24_PA_LOW);
  radio.setDataRate(RF24_250KBPS);
  radio.setChannel(90);
  radio.openReadingPipe(1, ADDR);
  radio.startListening();
}

void loop() {
  if (radio.available()) {
    radio.read(&pkt, sizeof(pkt));
    if (pkt.check == (uint16_t)(pkt.x + pkt.y + pkt.buttons + pkt.counter)) {
      lastPacket = millis();
      float speed = axis(pkt.y), turn = axis(pkt.x);     // check signs on your shield
      float limit = (pkt.buttons & (1 << 1)) ? 1.0f : 0.6f; // hold B for full speed
      drive((speed + turn) * limit, (speed - turn) * limit);
      digitalWrite(BUZZER, (pkt.buttons & 1) ? HIGH : LOW); // A = horn
      bool c = pkt.buttons & (1 << 2), cOld = lastButtons & (1 << 2);
      if (c && !cOld) { lights = !lights; digitalWrite(LED, lights); } // C = lights
      lastButtons = pkt.buttons;
    }
  }
  if (millis() - lastPacket > 300) { drive(0, 0); digitalWrite(BUZZER, LOW); }  // failsafe
}
