// Remote (transmitter): Arduino Uno + Joystick Shield V1.A + nRF24L01 on the shield header
// Shield pins: X=A0, Y=A1, A=D2, B=D3, C=D4, D=D5, E=D6, F=D7, K(stick press)=D8; nRF24: CE=D9, CSN=D10
// Library: RF24 (TMRh20). Put the shield switch on 5V for the Uno.
#include <SPI.h>
#include <RF24.h>

RF24 radio(9, 10);                        // CE, CSN
const byte ADDR[6] = "RTAK1";             // same address on the robot

struct Packet {                            // 8 bytes
  int16_t x, y;                            // -512..511
  uint8_t buttons;                         // bit0=A ... bit6=K (1 = pressed)
  uint8_t counter;                         // changes every packet
  uint16_t check;                          // simple checksum
} pkt;

const int BTN[7] = {2, 3, 4, 5, 6, 7, 8};

void setup() {
  Serial.begin(115200);
  for (int p : BTN) pinMode(p, INPUT_PULLUP);    // buttons pull the pin LOW when pressed
  if (!radio.begin()) Serial.println("nRF24 not found");
  radio.setPALevel(RF24_PA_LOW);           // LOW is enough on a table; HIGH for range
  radio.setDataRate(RF24_250KBPS);         // slower = longer range
  radio.setChannel(90);
  radio.openWritingPipe(ADDR);
  radio.stopListening();
}

void loop() {
  pkt.x = analogRead(A0) - 512;
  pkt.y = analogRead(A1) - 512;
  pkt.buttons = 0;
  for (int i = 0; i < 7; i++) if (digitalRead(BTN[i]) == LOW) pkt.buttons |= (1 << i);
  pkt.counter++;
  pkt.check = pkt.x + pkt.y + pkt.buttons + pkt.counter;
  bool ok = radio.write(&pkt, sizeof(pkt));
  if (!ok) Serial.println("no ACK");        // robot off or out of range
  delay(30);                                // about 33 packets per second
}
