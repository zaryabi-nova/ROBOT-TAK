// Simple 6-servo arm test with PCA9685: home pose + move one joint from Serial Monitor
// Type: <joint> <angle>   e.g.  2 120   (joint 0..5)
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca(0x40);
const int N = 6;
//                 base shoulder elbow wrist roll gripper
const int LO[N]   = {   0,     0,     0,    0,    0,   0};   // joint limits (deg)
const int HI[N]   = { 180,   180,   180,  180,  180,  90};
const int HOME[N] = {  90,    90,    90,   90,   90,  45};
int cur[N];
const int SMIN = 110, SMAX = 500;                             // pulses for 0 and 180 deg (calibrate)

void setAngle(int j, int deg) {
  deg = constrain(deg, LO[j], HI[j]);
  pca.setPWM(j, 0, map(deg, 0, 180, SMIN, SMAX));
  cur[j] = deg;
}

void moveSlow(int j, int target) {                            // 1 degree every 15 ms
  target = constrain(target, LO[j], HI[j]);
  while (cur[j] != target) {
    setAngle(j, cur[j] + (target > cur[j] ? 1 : -1));
    delay(15);
  }
}

void setup() {
  Serial.begin(115200);
  pca.begin();
  pca.setPWMFreq(50);
  for (int j = 0; j < N; j++) setAngle(j, HOME[j]);           // safe start pose
  Serial.println("Ready: <joint 0-5> <angle>");
}

void loop() {
  if (Serial.available()) {
    int j = Serial.parseInt(), a = Serial.parseInt();
    if (j >= 0 && j < N) { moveSlow(j, a); Serial.print("joint "); Serial.print(j); Serial.print(" = "); Serial.println(cur[j]); }
    while (Serial.available()) Serial.read();                 // drop rest of the line
  }
}
