// Project: Two-Wheel Self-Balancing Robot (simple version, no encoders)
// Arduino Uno + MPU6050 (SDA=A4, SCL=A5) + L298N (ENA/ENB jumpers ON) + 2 TT gear motors
// L298N inputs on PWM pins (as in the wiring figure): IN1=D11, IN2=D10 (left), IN3=D9, IN4=D6 (right). MPU INT (D2) not used.
// Angle: Kalman filter of chapter 8. Control: PID on the tilt angle, 200 times per second.
// Serial tuning: "p 21", "i 40", "d 0.8", "z 1.5" (balance angle, deg)
#include <Wire.h>
#include <math.h>

const int IN1 = 11, IN2 = 10, IN3 = 9, IN4 = 6;
const uint8_t MPU = 0x68;

float Kp = 21.0, Ki = 40.0, Kd = 0.8;            // start values: tune on your robot
float zeroAngle = 0.0;                           // angle where the robot stands by itself
const int MIN_PWM = 40;                          // TT gearboxes need a push to start
const float FALL_DEG = 40;                       // beyond this the motors stop

struct Kalman {                                  // same filter as chapter 8
  float Qa = 0.001, Qb = 0.003, R = 0.03, angle = 0, bias = 0, P[2][2] = {{1, 0}, {0, 1}};
  float update(float acc, float rate, float dt) {
    angle += dt * (rate - bias);
    P[0][0] += dt * (dt * P[1][1] - P[0][1] - P[1][0] + Qa);
    P[0][1] -= dt * P[1][1]; P[1][0] -= dt * P[1][1]; P[1][1] += Qb * dt;
    float S = P[0][0] + R, K0 = P[0][0] / S, K1 = P[1][0] / S, y = acc - angle;
    angle += K0 * y; bias += K1 * y;
    float P00 = P[0][0], P01 = P[0][1];
    P[0][0] -= K0 * P00; P[0][1] -= K0 * P01; P[1][0] -= K1 * P00; P[1][1] -= K1 * P01;
    return angle;
  }
} kf;

float gyroOffset = 0, integral = 0;
bool fallen = true;
unsigned long last;

int16_t read16() { int16_t v = Wire.read() << 8; return v | Wire.read(); }
void readMPU(float &accAngle, float &rate) {
  Wire.beginTransmission(MPU); Wire.write(0x3B); Wire.endTransmission(false);
  Wire.requestFrom(MPU, (uint8_t)14);
  read16(); int16_t ay = read16(), az = read16(); read16();
  int16_t gx = read16(); read16(); read16();
  accAngle = atan2((float)ay, (float)az) * 180.0 / M_PI;   // tilt around the X axis
  rate = gx / 131.0 - gyroOffset;                         // deg/s
}

void motor(int a, int b, int u) {               // L298N: PWM on one input, the other LOW
  if (u != 0) u += (u > 0 ? MIN_PWM : -MIN_PWM);
  u = constrain(u, -255, 255);
  if (u >= 0) { analogWrite(a, u); analogWrite(b, 0); }
  else        { analogWrite(a, 0); analogWrite(b, -u); }
}
void drive(int u) { motor(IN1, IN2, u); motor(IN3, IN4, u); }

void readSerial() {
  if (!Serial.available()) return;
  char c = Serial.read(); float v = Serial.parseFloat();
  if (c == 'p') Kp = v;
  else if (c == 'i') { Ki = v; integral = 0; }
  else if (c == 'd') Kd = v;
  else if (c == 'z') zeroAngle = v;
}

void setup() {
  Serial.begin(115200);
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  Wire.begin(); Wire.setClock(400000);
  Wire.beginTransmission(MPU); Wire.write(0x6B); Wire.write(0); Wire.endTransmission();  // wake up
  delay(200);
  float sum = 0, a, r;                           // keep the robot still: gyro calibration
  for (int i = 0; i < 300; i++) { readMPU(a, r); sum += r; delay(3); }
  gyroOffset = sum / 300;
  readMPU(a, r); kf.angle = a;
  last = micros();
}

void loop() {
  readSerial();
  unsigned long now = micros();
  if (now - last < 5000) return;                 // 200 Hz
  float dt = (now - last) * 1e-6; last = now;

  float acc, rate; readMPU(acc, rate);
  float angle = kf.update(acc, rate, dt);
  float err = angle - zeroAngle;

  if (fabs(err) > FALL_DEG) fallen = true;       // fell over
  if (fallen && fabs(err) < 3) { fallen = false; integral = 0; }   // stand it up by hand
  if (fallen) { drive(0); return; }

  integral = constrain(integral + err * dt, -3.0, 3.0);            // anti-windup
  float u = Kp * err + Ki * integral + Kd * rate;
  drive((int)u);

  static int n = 0;
  if (++n % 10 == 0) { Serial.print(angle); Serial.print(' '); Serial.println(u); }
}
