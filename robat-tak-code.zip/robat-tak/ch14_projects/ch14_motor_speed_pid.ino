// Project: speed control of one encoder motor with PID (Arduino Uno + TB6612FNG + JGA25-370)
// Target speed from a potentiometer, or from Serial: "s 80" (rpm), "p 1.2", "i 4", "d 0", "s off"
// Open Tools > Serial Plotter to see target, rpm and pwm.
const int ENC_A = 2, ENC_B = 4;                 // encoder (A on interrupt pin 2)
const int PWMA = 5, AIN1 = 7, AIN2 = 8, STBY = 6; // TB6612FNG channel A
const int POT = A0;

const float PPR = 11, GEAR = 34;                 // encoder pulses per motor turn, gear ratio
const float CPR = 2 * PPR * GEAR;                // counts per output turn (CHANGE on A = x2)
const unsigned long DT_MS = 20;                  // control period: 50 Hz
const float MAX_RPM = 120;

volatile long ticks = 0;
float Kp = 2.0, Ki = 15.0, Kd = 0.0;              // start values; tune on your motor
float integral = 0, prevErr = 0, rpmF = 0;
bool serialTarget = false; float target = 0;
unsigned long tPrev = 0; long ticksPrev = 0;

void onA() {                                     // direction from B at every edge of A
  bool a = digitalRead(ENC_A), b = digitalRead(ENC_B);
  ticks += (a == b) ? 1 : -1;                    // swap the signs if forward reads negative
}

void setMotor(int pwm) {                         // -255..255
  pwm = constrain(pwm, -255, 255);
  digitalWrite(AIN1, pwm > 0);
  digitalWrite(AIN2, pwm < 0);
  analogWrite(PWMA, abs(pwm));
}

void readSerial() {
  if (!Serial.available()) return;
  char c = Serial.read();
  String v = Serial.readStringUntil('\n'); v.trim();
  if (c == 's') { serialTarget = (v != "off"); target = v.toFloat(); }
  if (c == 'p') Kp = v.toFloat();
  if (c == 'i') { Ki = v.toFloat(); integral = 0; }
  if (c == 'd') Kd = v.toFloat();
}

void setup() {
  Serial.begin(115200);
  pinMode(ENC_A, INPUT_PULLUP); pinMode(ENC_B, INPUT_PULLUP);
  pinMode(PWMA, OUTPUT); pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT); pinMode(STBY, OUTPUT);
  digitalWrite(STBY, HIGH);                      // enable TB6612
  attachInterrupt(digitalPinToInterrupt(ENC_A), onA, CHANGE);
}

void loop() {
  readSerial();
  unsigned long now = millis();
  if (now - tPrev < DT_MS) return;
  float dt = (now - tPrev) / 1000.0; tPrev = now;

  noInterrupts(); long t = ticks; interrupts();
  float rpm = (t - ticksPrev) / CPR / dt * 60.0; ticksPrev = t;
  rpmF = 0.7 * rpmF + 0.3 * rpm;                 // light low-pass filter

  if (!serialTarget) target = map(analogRead(POT), 0, 1023, -MAX_RPM, MAX_RPM);
  if (fabs(target) < 5) target = 0;              // dead zone around zero

  float err = target - rpmF;
  integral += err * dt;
  integral = constrain(integral, -17, 17);       // anti-windup: Ki*17 = about 255
  float deriv = (err - prevErr) / dt; prevErr = err;
  float out = Kp * err + Ki * integral + Kd * deriv;
  if (target == 0 && fabs(rpmF) < 3) { out = 0; integral = 0; }   // rest quietly at zero
  setMotor((int)out);

  Serial.print("target:"); Serial.print(target);
  Serial.print(",rpm:");   Serial.print(rpmF);
  Serial.print(",pwm:");   Serial.println(out);
}
