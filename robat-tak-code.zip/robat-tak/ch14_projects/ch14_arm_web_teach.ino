// Project: Pick-and-Place Robotic Arm controlled from a web page (ESP32 + 4x MG90S)
// Joints: 0 base (GPIO13), 1 shoulder (GPIO12), 2 elbow (GPIO14), 3 gripper (GPIO27)
// Servos powered from a separate 5V 3A supply; common GND with the ESP32.
// Library: ESP32Servo. Phone: join Wi-Fi "RoboArm" (pass robot1234) and open 192.168.4.1
// HTTP API (also used by the mobile app chapter): /set?j=0&a=90  /all?a=90,90,90,60  /home  /save  /play  /stop  /clear  /state
#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>

const int N = 4;
const int PIN[N]  = {13, 12, 14, 27};
const int LO[N]   = {0, 15, 0, 10};             // joint limits (deg): keep the arm off the table
const int HI[N]   = {180, 165, 180, 80};
const int HOME_[N] = {90, 90, 90, 60};
const int STEP_MS = 12;                          // smooth motion: 1 degree every 12 ms

Servo servo[N];
WebServer server(80);
int cur[N], target[N];
const int MAXP = 20;                             // up to 20 saved poses
int poses[MAXP][N]; int nPoses = 0;
bool playing = false; int playIdx = 0; unsigned long reachedAt = 0;

const char PAGE[] PROGMEM = R"HTML(<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>RoboArm</title>
<style>body{font-family:sans-serif;max-width:420px;margin:auto;padding:10px;background:#f4f7fb}
label{display:block;margin-top:14px;font-weight:bold}input[type=range]{width:100%}
button{font-size:17px;margin:6px 3px;padding:10px 14px;border:0;border-radius:8px;background:#1f3a5f;color:#fff}
#st{margin-top:12px}</style></head><body><h2>RoboArm</h2>
<label>Base <span id="v0"></span></label><input type="range" min="0" max="180" id="j0">
<label>Shoulder <span id="v1"></span></label><input type="range" min="0" max="180" id="j1">
<label>Elbow <span id="v2"></span></label><input type="range" min="0" max="180" id="j2">
<label>Gripper <span id="v3"></span></label><input type="range" min="0" max="180" id="j3">
<div><button onclick="cmd('home')">Home</button><button onclick="cmd('save')">Save pose</button>
<button onclick="cmd('play')">Play</button><button onclick="cmd('stop')">Stop</button>
<button onclick="cmd('clear')">Clear</button></div><div id="st"></div>
<script>
for(let j=0;j<4;j++){const s=document.getElementById('j'+j);
 s.oninput=()=>{document.getElementById('v'+j).textContent=s.value;fetch(`/set?j=${j}&a=${s.value}`);};}
function cmd(c){fetch('/'+c).then(refresh);}
async function refresh(){const s=await (await fetch('/state')).json();
 for(let j=0;j<4;j++){const e=document.getElementById('j'+j);
  if(document.activeElement!==e){e.value=s.target[j];document.getElementById('v'+j).textContent=s.target[j];}}
 document.getElementById('st').textContent=`Saved poses: ${s.poses}  ${s.playing?'(playing)':''}`;}
refresh();setInterval(refresh,1000);
</script></body></html>)HTML";

void setTarget(int j, int a) { target[j] = constrain(a, LO[j], HI[j]); }

void handleSet() {
  playing = false;                               // manual move stops playback
  int j = server.arg("j").toInt();
  if (j >= 0 && j < N) setTarget(j, server.arg("a").toInt());
  server.send(200, "text/plain", "ok");
}
void handleAll() {                              // /all?a=base,shoulder,elbow,gripper (one request for the app)
  playing = false;
  String a = server.arg("a"); int from = 0;
  for (int j = 0; j < N; j++) {
    int comma = a.indexOf(',', from);
    String part = (comma < 0) ? a.substring(from) : a.substring(from, comma);
    if (part.length()) setTarget(j, part.toInt());
    if (comma < 0) break;
    from = comma + 1;
  }
  server.send(200, "text/plain", "ok");
}
void handleState() {
  String s = "{\"target\":[";
  for (int j = 0; j < N; j++) { s += target[j]; if (j < N - 1) s += ","; }
  s += "],\"poses\":" + String(nPoses) + ",\"playing\":" + (playing ? "true" : "false") + "}";
  server.send(200, "application/json", s);
}

void setup() {
  Serial.begin(115200);
  for (int j = 0; j < N; j++) {
    servo[j].setPeriodHertz(50);
    servo[j].attach(PIN[j], 500, 2400);         // MG90S pulse range (us)
    cur[j] = target[j] = HOME_[j];
    servo[j].write(cur[j]);
  }
  WiFi.softAP("RoboArm", "robot1234");
  server.on("/", []() { server.send_P(200, "text/html", PAGE); });
  server.on("/set", handleSet);
  server.on("/all", handleAll);
  server.on("/state", handleState);
  server.on("/home", []() { playing = false; for (int j = 0; j < N; j++) setTarget(j, HOME_[j]); server.send(200, "text/plain", "ok"); });
  server.on("/save", []() { if (nPoses < MAXP) { for (int j = 0; j < N; j++) poses[nPoses][j] = target[j]; nPoses++; } server.send(200, "text/plain", "ok"); });
  server.on("/play", []() { if (nPoses) { playing = true; playIdx = 0; reachedAt = 0; } server.send(200, "text/plain", "ok"); });
  server.on("/stop", []() { playing = false; server.send(200, "text/plain", "ok"); });
  server.on("/clear", []() { playing = false; nPoses = 0; server.send(200, "text/plain", "ok"); });
  server.begin();
  Serial.println(WiFi.softAPIP());
}

void loop() {
  server.handleClient();
  static unsigned long lastStep = 0;
  if (millis() - lastStep >= STEP_MS) {          // move every joint 1 degree toward its target
    lastStep = millis();
    bool moving = false;
    for (int j = 0; j < N; j++)
      if (cur[j] != target[j]) { cur[j] += (target[j] > cur[j]) ? 1 : -1; servo[j].write(cur[j]); moving = true; }
    if (playing) {                               // playback: next pose 400 ms after reaching one
      if (moving) reachedAt = 0;
      else if (!reachedAt) reachedAt = millis();
      else if (millis() - reachedAt > 400) {
        for (int j = 0; j < N; j++) setTarget(j, poses[playIdx][j]);
        playIdx = (playIdx + 1) % nPoses;
        reachedAt = 0;
      }
    }
  }
}
