/* Rabat Tak - Vol.2 Project 14-5: STM32 two-wheel robot, encoder PID + Bluetooth
 * Board: NUCLEO-F446RE, SYSCLK 84 MHz (CubeMX board default), APB1 timer clock 84 MHz
 * CubeMX: TIM2 PWM CH1=PA0 CH2=PA1, PSC=0, ARR=4199 (20 kHz)
 *         TIM3 Encoder TI1&TI2 PA6/PA7, TIM4 Encoder TI1&TI2 PB6/PB7, ARR=65535
 *         TIM6 PSC=8399 ARR=99 (100 Hz) + global interrupt
 *         USART1 PA9/PA10 9600 (HC-05) + global interrupt; USART2 115200 (ST-LINK VCP)
 *         GPIO out: PA8=AIN1 PB10=AIN2 PB4=BIN1 PB5=BIN2 PA4=STBY
 * Bluetooth: F B L R S = move, 1..9 = speed. Telemetry: "tL,mL,tR,mR" rpm on USART2 */

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
#define CPR 1496.0f            /* 11 pulses x4 edges x34 gear */
#define DT  0.01f              /* 100 Hz */
#define KP 60.0f
#define KI 400.0f
#define PWM_MAX 4199
typedef struct { TIM_HandleTypeDef *enc; uint16_t last; float target, rpm, integ; int pwm; } Wheel;
Wheel wl = {&htim3}, wr = {&htim4};
volatile uint32_t lastCmd = 0;
volatile uint8_t telem = 0, rx;
float maxRpm = 90.0f;
/* USER CODE END PV */

/* USER CODE BEGIN 0 */
int __io_putchar(int ch) { HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 10); return ch; }

static void motor(int pwm, GPIO_TypeDef *p1, uint16_t n1, GPIO_TypeDef *p2, uint16_t n2, uint32_t ch)
{
  HAL_GPIO_WritePin(p1, n1, pwm > 0 ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(p2, n2, pwm < 0 ? GPIO_PIN_SET : GPIO_PIN_RESET);
  __HAL_TIM_SET_COMPARE(&htim2, ch, abs(pwm));
}

static void wheelUpdate(Wheel *w)
{
  uint16_t now = __HAL_TIM_GET_COUNTER(w->enc);
  int16_t d = (int16_t)(now - w->last);          /* wrap-around safe */
  w->last = now;
  w->rpm = 0.7f * w->rpm + 0.3f * (d / CPR / DT * 60.0f);
  float e = w->target - w->rpm;
  if (w->target == 0 && fabsf(w->rpm) < 2) { w->integ = 0; w->pwm = 0; return; }
  w->integ += e * DT;
  if (w->integ >  PWM_MAX / KI) w->integ =  PWM_MAX / KI;   /* anti-windup */
  if (w->integ < -PWM_MAX / KI) w->integ = -PWM_MAX / KI;
  float u = KP * e + KI * w->integ;
  if (u >  PWM_MAX) u =  PWM_MAX;
  if (u < -PWM_MAX) u = -PWM_MAX;
  w->pwm = (int)u;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance != TIM6) return;
  if (HAL_GetTick() - lastCmd > 500) wl.target = wr.target = 0;   /* failsafe */
  wheelUpdate(&wl); wheelUpdate(&wr);
  motor(wl.pwm, GPIOA, GPIO_PIN_8, GPIOB, GPIO_PIN_10, TIM_CHANNEL_1);
  motor(wr.pwm, GPIOB, GPIO_PIN_4, GPIOB, GPIO_PIN_5, TIM_CHANNEL_2);
  static uint8_t n; if (++n >= 10) { n = 0; telem = 1; }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance != USART1) return;
  float v = maxRpm;
  switch (rx) {
    case 'F': wl.target =  v;      wr.target =  v;      break;
    case 'B': wl.target = -v;      wr.target = -v;      break;
    case 'L': wl.target = -v / 2;  wr.target =  v / 2;  break;
    case 'R': wl.target =  v / 2;  wr.target = -v / 2;  break;
    case 'S': wl.target = 0;       wr.target = 0;       break;
    default: if (rx >= '1' && rx <= '9') maxRpm = 20.0f * (rx - '0');
  }
  lastCmd = HAL_GetTick();
  HAL_UART_Receive_IT(&huart1, (uint8_t *)&rx, 1);
}
/* USER CODE END 0 */

/* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);          /* STBY high */
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
  HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
  HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
  wl.last = __HAL_TIM_GET_COUNTER(&htim3);
  wr.last = __HAL_TIM_GET_COUNTER(&htim4);
  HAL_UART_Receive_IT(&huart1, (uint8_t *)&rx, 1);
  HAL_TIM_Base_Start_IT(&htim6);
  printf("STM32 robot ready\r\n");
/* USER CODE END 2 */

/* USER CODE BEGIN WHILE */
  while (1)
  {
    if (telem) {
      telem = 0;
      printf("%d,%d,%d,%d\r\n", (int)wl.target, (int)wl.rpm, (int)wr.target, (int)wr.rpm);
    }
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (HAL_GetTick() - lastCmd < 500) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
/* USER CODE END 3 */
