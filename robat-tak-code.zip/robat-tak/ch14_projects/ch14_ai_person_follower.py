"""Project: Raspberry Pi AI Vision Robot - follows a person
Raspberry Pi 5 + AI HAT+ (Hailo) + JT-ZERO-V2.0 camera (OV5647, 22-pin cable; Camera Module 3 also works) + TB6612FNG (or L298N) + 2 DC gear motors
Install (Raspberry Pi OS 64-bit):  sudo apt install hailo-all python3-picamera2 python3-gpiozero ; sudo reboot
Check:   hailortcli fw-control identify      and      ls /usr/share/hailo-models
Run:     python3 ch14_ai_person_follower.py           (--test: no motors, only print)
"""
import sys, time

import os
# 26 TOPS (Hailo-8) -> *_h8.hef ; 13 TOPS (Hailo-8L) -> *_h8l.hef
MODELS = ["/usr/share/hailo-models/yolov8s_h8.hef",
          "/usr/share/hailo-models/yolov8s_h8l.hef"]
MODEL = next((m for m in MODELS if os.path.exists(m)), MODELS[-1])
PERSON = 0                                          # COCO class 0 = person
SCORE = 0.5
TARGET_H = 0.55          # wanted person height in the image (0..1): bigger = stop closer
K_TURN, K_FWD = 1.2, 1.5
MAX_SPEED = 0.6
LOST_S = 0.5             # no person for this long -> stop

def best_person(hailo_output, score=SCORE):
    """Return (cx, h, score) of the largest person box, coordinates 0..1, or None."""
    best = None
    for det in hailo_output[PERSON]:
        y0, x0, y1, x1, s = det[:5]
        if s < score:
            continue
        h = y1 - y0
        if best is None or h > best[1]:
            best = ((x0 + x1) / 2, h, s)
    return best

def control(person):
    """Person -> (left, right) motor values in -1..1."""
    if person is None:
        return 0.0, 0.0
    cx, h, _ = person
    turn = K_TURN * (cx - 0.5)                      # person on the right -> turn right
    fwd = K_FWD * (TARGET_H - h)                    # far (small box) -> forward; too close -> back
    if h > TARGET_H + 0.15:                         # very close: never drive forward
        fwd = min(fwd, 0.0)
    clamp = lambda v: max(-MAX_SPEED, min(MAX_SPEED, v))
    return clamp(fwd + turn), clamp(fwd - turn)

def main():
    test = "--test" in sys.argv
    from picamera2 import Picamera2
    from picamera2.devices import Hailo
    robot = None
    if not test:
        from gpiozero import Robot, Motor
        robot = Robot(left=Motor(forward=5, backward=6, enable=12),
                      right=Motor(forward=16, backward=26, enable=13))
    with Hailo(MODEL) as hailo:
        model_h, model_w, _ = hailo.get_input_shape()
        with Picamera2() as cam:
            main_cfg = {"size": (640, 480), "format": "XRGB8888"}
            lores = {"size": (model_w, model_h), "format": "RGB888"}
            cam.configure(cam.create_preview_configuration(main_cfg, lores=lores))
            cam.start()
            last_seen = 0.0
            try:
                while True:
                    frame = cam.capture_array("lores")
                    person = best_person(hailo.run(frame))
                    if person:
                        last_seen = time.time()
                    if time.time() - last_seen > LOST_S:
                        person = None
                    left, right = control(person)
                    if robot:
                        robot.value = (left, right)
                    print(person and f"x={person[0]:.2f} h={person[1]:.2f}", f"L={left:+.2f} R={right:+.2f}")
            except KeyboardInterrupt:
                pass
            finally:
                if robot:
                    robot.stop()

if __name__ == "__main__":
    main()
