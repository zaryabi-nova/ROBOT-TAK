// ESP32 robot: web joystick control + RFID unlock/stations + SMS alarm on high temperature
// Libraries: MFRC522 (miguelbalboa), OneWire, DallasTemperature
#include <WiFi.h>
#include <WebServer.h>
#include <SPI.h>
#include <MFRC522.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ---------- pins
const int ENA = 25, IN1 = 26, IN2 = 27;          // left motor
const int ENB = 14, IN3 = 32, IN4 = 33;          // right motor
const int RFID_SS = 5, RFID_RST = 4;             // RC522 (SPI: SCK18 MISO19 MOSI23)
const int TEMP_PIN = 13;                         // DS18B20 data (4.7k pull-up to 3.3V)
const int MODEM_RX = 16, MODEM_TX = 17;          // A7670E UART

// ---------- settings
const char *AP_NAME = "RoboTak", *AP_PASS = "robot1234";
const char *PHONE = "+98912xxxxxxx";             // number that receives the SMS
const String MASTER_UID = "A1B2C3D4";            // card that unlocks the robot (read it from Serial)
const float TEMP_ALARM = 50.0, TEMP_RESET = 45.0;

WebServer server(80);
MFRC522 rfid(RFID_SS, RFID_RST);
OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);
HardwareSerial modem(2);

bool unlocked = false, alarmSent = false;
float temperature = 0;
String lastTag = "-";
unsigned long lastCmd = 0, lastTempRead = 0;

const char PAGE[] PROGMEM = R"HTML(<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>RoboTak</title>
<style>body{font-family:sans-serif;text-align:center;background:#f4f7fb;margin:0}
#pad{width:260px;height:260px;margin:20px auto;border-radius:50%;background:#1f3a5f;position:relative;touch-action:none}
#knob{width:80px;height:80px;border-radius:50%;background:#fff;position:absolute;left:90px;top:90px}
#st{font-size:18px;line-height:1.8}</style></head><body>
<h2>RoboTak</h2><div id="pad"><div id="knob"></div></div><div id="st">...</div>
<script>
const pad=document.getElementById('pad'),knob=document.getElementById('knob');
let v=0,w=0,active=false;
function move(e){const r=pad.getBoundingClientRect();
 let x=(e.clientX-r.left-130)/130,y=(e.clientY-r.top-130)/130;
 const d=Math.hypot(x,y);if(d>1){x/=d;y/=d;}
 knob.style.left=(90+x*90)+'px';knob.style.top=(90+y*90)+'px';v=-y;w=-x;}
pad.onpointerdown=e=>{active=true;pad.setPointerCapture(e.pointerId);move(e);};
pad.onpointermove=e=>{if(active)move(e);};
pad.onpointerup=()=>{active=false;v=0;w=0;knob.style.left='90px';knob.style.top='90px';};
setInterval(()=>fetch(`/cmd?v=${v.toFixed(2)}&w=${w.toFixed(2)}`),100);
setInterval(async()=>{const s=await (await fetch('/status')).json();
 document.getElementById('st').innerHTML=
 `Temp: ${s.temp.toFixed(1)} C<br>Tag: ${s.tag}<br>${s.unlocked?'UNLOCKED':'LOCKED - show the card'}`;},1000);
</script></body></html>)HTML";

void motor(int en, int a, int b, float s) {      // s: -1..1
  s = constrain(s, -1.0f, 1.0f);
  digitalWrite(a, s > 0);
  digitalWrite(b, s < 0);
  analogWrite(en, (int)(fabs(s) * 255));
}
void drive(float l, float r) { motor(ENA, IN1, IN2, l); motor(ENB, IN3, IN4, r); }

void handleCmd() {
  float v = server.arg("v").toFloat(), w = server.arg("w").toFloat();
  if (unlocked) drive(v - 0.6f * w, v + 0.6f * w);
  else drive(0, 0);
  lastCmd = millis();
  server.send(200, "text/plain", "ok");
}

void handleStatus() {
  String json = "{\"temp\":" + String(temperature, 1) + ",\"tag\":\"" + lastTag +
                "\",\"unlocked\":" + (unlocked ? "true" : "false") + "}";
  server.send(200, "application/json", json);
}

bool sendSMS(const String &text) {                // AT commands (A7670E / SIM800 family)
  modem.println("AT+CMGF=1"); delay(300);        // text mode
  modem.print("AT+CMGS=\""); modem.print(PHONE); modem.println("\""); delay(500);
  modem.print(text);
  modem.write(26);                               // Ctrl+Z: send
  unsigned long t0 = millis();
  String reply;
  while (millis() - t0 < 10000) {                 // wait for +CMGS (sent) or ERROR
    while (modem.available()) reply += (char)modem.read();
    if (reply.indexOf("+CMGS") >= 0) return true;
    if (reply.indexOf("ERROR") >= 0) return false;
  }
  return false;
}

void checkRfid() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  String uid;
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  Serial.println("Card: " + uid);
  if (uid == MASTER_UID) unlocked = !unlocked;    // master card: lock / unlock
  else lastTag = uid;                             // other tags: stations on the floor
  rfid.PICC_HaltA();
}

void checkTemperature() {
  if (millis() - lastTempRead < 2000) return;
  lastTempRead = millis();
  tempSensor.requestTemperatures();
  temperature = tempSensor.getTempCByIndex(0);
  if (temperature >= TEMP_ALARM && !alarmSent) {
    drive(0, 0);
    unlocked = false;                             // stop and lock the robot
    alarmSent = sendSMS("RoboTak ALARM: temperature " + String(temperature, 1) + " C. Robot stopped.");
  }
  if (temperature <= TEMP_RESET) alarmSent = false;   // hysteresis: arm again after cooling
}

void setup() {
  int outs[] = {ENA, IN1, IN2, ENB, IN3, IN4};
  for (int p : outs) pinMode(p, OUTPUT);
  Serial.begin(115200);
  modem.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);
  SPI.begin();
  rfid.PCD_Init();
  tempSensor.begin();
  WiFi.softAP(AP_NAME, AP_PASS);                  // robot makes its own Wi-Fi
  Serial.println(WiFi.softAPIP());                // usually 192.168.4.1
  server.on("/", []() { server.send_P(200, "text/html", PAGE); });
  server.on("/cmd", handleCmd);
  server.on("/status", handleStatus);
  server.begin();
}

void loop() {
  server.handleClient();
  checkRfid();
  checkTemperature();
  if (millis() - lastCmd > 500) drive(0, 0);      // safety: page closed or Wi-Fi lost -> stop
}
