// Bench test of ONE brushless motor + ESC with a potentiometer (NO PROPELLER!)
// ESC signal -> D9, pot middle pin -> A0, common GND between ESC and Arduino.
// The ESC is powered from the LiPo; its 5V BEC wire is NOT connected to the Arduino 5V.
#include <Servo.h>

Servo esc;
const int ESC_PIN = 9, POT = A0;
const int MIN_US = 1000, MAX_US = 2000;   // standard ESC throttle range
const int LIMIT_US = 1300;                // keep the bench test gentle

void setup() {
  Serial.begin(115200);
  esc.attach(ESC_PIN, MIN_US, MAX_US);
  esc.writeMicroseconds(MIN_US);          // zero throttle so the ESC arms
  Serial.println("Arming... turn the pot fully down");
  delay(3000);
}

void loop() {
  int us = map(analogRead(POT), 0, 1023, MIN_US, LIMIT_US);
  if (us < MIN_US + 30) us = MIN_US;      // small dead zone at the bottom
  esc.writeMicroseconds(us);
  Serial.println(us);
  delay(20);
}
