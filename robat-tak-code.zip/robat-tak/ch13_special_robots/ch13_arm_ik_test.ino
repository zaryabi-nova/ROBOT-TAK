// Two-joint arm test: Arduino + PCA9685 + 2 servos (shoulder ch0, elbow ch1)
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
#include <math.h>

Adafruit_PWMServoDriver pca(0x40);
const float L1 = 100, L2 = 80;                 // link lengths (mm)
const int SMIN = 110, SMAX = 500;               // pulse counts for 0 and 180 degrees (calibrate!)
float cur[2] = {90, 90};                         // current servo angles (deg)

void writeServo(int ch, float deg) {
  deg = constrain(deg, 0, 180);                  // joint limits
  pca.setPWM(ch, 0, map((long)deg, 0, 180, SMIN, SMAX));
}

void moveSmooth(float a0, float a1, int steps = 50) {   // ramp instead of jumping
  float s0 = cur[0], s1 = cur[1];
  for (int i = 1; i <= steps; i++) {
    writeServo(0, s0 + (a0 - s0) * i / steps);
    writeServo(1, s1 + (a1 - s1) * i / steps);
    delay(15);
  }
  cur[0] = a0; cur[1] = a1;
}

bool goTo(float x, float y) {                    // inverse kinematics, elbow up
  float c2 = (x * x + y * y - L1 * L1 - L2 * L2) / (2 * L1 * L2);
  if (fabs(c2) > 1) return false;                // out of reach
  float s2 = -sqrt(1 - c2 * c2);
  float t2 = atan2(s2, c2);
  float t1 = atan2(y, x) - atan2(L2 * s2, L1 + L2 * c2);
  float shoulder = degrees(t1);                  // 0..180 with servo horn along +x at 0
  float elbow = 180 + degrees(t2);               // elbow servo mounted so 180 = straight arm
  moveSmooth(shoulder, elbow);
  return true;
}

void setup() {
  Serial.begin(115200);
  pca.begin();
  pca.setPWMFreq(50);                            // standard servo frame: 50 Hz
  delay(500);
  moveSmooth(90, 180);                           // start pose
}

void loop() {
  const float pts[][2] = {{120, 50}, {150, 0}, {50, 120}};
  for (auto &p : pts) {
    Serial.println(goTo(p[0], p[1]) ? "ok" : "out of reach");
    delay(1000);
  }
}
